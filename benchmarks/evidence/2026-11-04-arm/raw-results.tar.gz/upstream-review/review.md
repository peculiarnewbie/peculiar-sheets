# Competitor internals review

Reviewed 2026-11-03 against Peculiar Sheets PR #5, source f7fb184 (tree identical to 8d6c86c). This is a source investigation, not a new optimization benchmark. No production code or benchmark workload was changed.

## Main conclusion

There are credible structural experiments left. The strongest new lead is the division between sparse row metrics and full-axis virtualizer caches. We already use several of the competitors' successful patterns: bounded viewport owners, row-scoped subscriptions, lazy revision sources, and sparse row-height overrides. Repeating those changes or merely changing transforms is unlikely to produce a new result.

The next investigation should count geometry invalidations and retained allocations before another broad optimization goal. Source review identifies mechanisms; it does not prove why a library won a particular timing sample.

## Checkouts and provenance

All five upstream repositories are cloned under `.benchmark/upstream/`. They are shallow, sparse checkouts of the relevant source directories; full Git histories and unrelated examples/assets were not downloaded. The manifest records remotes, exact commits, refs, package versions and checked-out directories.

| Package | Benchmarked version | Source commit | Verification |
| --- | --- | --- | --- |
| ag-grid-community | 36.2.0 | 0fee5b7b1e83 | npm gitHead and source package version match |
| handsontable | 18.1.2 | d6c4159ae8af | release tag and source package version match |
| @revolist/revogrid | 4.30.0 | 52f2aab0697b | npm gitHead and source package version match |
| @gridsheet/react-core | 3.6.0 | b39308f5eec9 | release tag and source package version match |
| @univerjs/core | 1.3.1 | c6178bb0aae5 | release tag and source package version match |

RevoGrid's v4.30.0 tag points to a tree whose package.json still says 4.29.1. The checkout was corrected to npm's recorded gitHead, 52f2aab0697b70811ee704ef72046bb8aab418e8, whose package version is 4.30.0. The intervening diff changes only the package version; all reviewed src files are identical. AG Grid also matches npm's gitHead. npm does not expose a gitHead for the other three versions; their release tags and source package versions match, without claiming a byte-for-byte reproduction of the published bundles.

## AG Grid: explicit changed rows, equality checks, scheduled viewport work

The benchmark's independent-write adapter calls rowNode.updateData. Its batch adapter collects distinct changed row objects and submits one applyTransaction update. These are the relevant paths, rather than a hypothetical full data reload on every write.

[RowNode.updateData](https://github.com/ag-grid/ag-grid/blob/0fee5b7b1e839ae23fe860e404042448f3c1375d/packages/ag-grid-community/src/entities/rowNode.ts#L362) assigns the row data and dispatches row-local and grid events. [RowCtrl.onRowNodeDataChanged](https://github.com/ag-grid/ag-grid/blob/0fee5b7b1e839ae23fe860e404042448f3c1375d/packages/ag-grid-community/src/rendering/row/rowCtrl.ts#L702) refreshes the rendered row, and [CellCtrl.refreshCell](https://github.com/ag-grid/ag-grid/blob/0fee5b7b1e839ae23fe860e404042448f3c1375d/packages/ag-grid-community/src/rendering/cell/cellCtrl.ts#L624) compares the value/format result before replacing displayed content. Offscreen rows do not have rendered row/cell controllers. This is a useful model for keeping model mutation, visible-cell refresh, and optional style/editor work separate. It does not mean AG Grid runs no global bookkeeping.

[ClientSideNodeManager.setImmutableRowData](https://github.com/ag-grid/ag-grid/blob/0fee5b7b1e839ae23fe860e404042448f3c1375d/packages/ag-grid-community/src/clientSideRowModel/clientSideNodeManager.ts#L86) maintains stable row nodes and skips a row update when its data object is unchanged. That shortcut cannot simply replace our reconciliation: the benchmark creates fresh row objects for AG Grid and clones every input matrix row even in the three-cell-change case. Our controlled API also does not currently promise immutable row inputs. A row-reference shortcut would need an explicit contract, not a benchmark-specific assumption.

[GridBodyScrollFeature](https://github.com/ag-grid/ag-grid/blob/0fee5b7b1e839ae23fe860e404042448f3c1375d/packages/ag-grid-community/src/gridBodyComp/gridBodyScrollFeature.ts#L299) retains the latest scroll offset and schedules work through [AnimationFrameService](https://github.com/ag-grid/ag-grid/blob/0fee5b7b1e839ae23fe860e404042448f3c1375d/packages/ag-grid-community/src/misc/animationFrameService.ts#L1). Row and cell creation tasks are ordered; destruction runs after creation. [RowRenderer.redraw](https://github.com/ag-grid/ag-grid/blob/0fee5b7b1e839ae23fe860e404042448f3c1375d/packages/ag-grid-community/src/rendering/rowRenderer.ts#L1089) exits early when a scroll has not changed the rendered range. This is real source evidence for avoiding redundant work. It is not evidence that adding another RAF to our pipeline would help: Solid already batches rendering, and an extra frame can worsen verified latency. AG Grid's scheduler can also spread work across frames, which matters when interpreting two-frame completion proxies.

**Experiment:** profile notifications and actual DOM writes for one visible row plus offscreen mutations, preserving history and formula synchronization. Check whether unchanged text triggers unrelated class/title/geometry work. Keep value derivations local in native Solid memos only where profiling supports their cost; do not restore the reverted per-cell presentation snapshot wholesale.

## RevoGrid: sparse dimensions and a rotating viewport

[calculateDimensionData](https://github.com/revolist/revogrid/blob/52f2aab0697b70811ee704ef72046bb8aab418e8/src/store/dimension/dimension.helpers.ts#L31) stores the default item size plus changed-size indexes and coordinates. With no overrides, position lookup is arithmetic; only override entries are indexed. [ViewportStore.setViewPortCoordinate](https://github.com/revolist/revogrid/blob/52f2aab0697b70811ee704ef72046bb8aab418e8/src/store/vp/viewport.store.ts#L74) computes the window, and [recombineByOffset](https://github.com/revolist/revogrid/blob/52f2aab0697b70811ee704ef72046bb8aab418e8/src/store/vp/viewport.helpers.ts#L239) rotates the viewport item array, replacing the records that cross a boundary. It does not need a start/size record for every default-sized row. Data ordering is stored separately as numeric indexes in [DataStore.updateData](https://github.com/revolist/revogrid/blob/52f2aab0697b70811ee704ef72046bb8aab418e8/src/store/dataSource/data.store.ts#L97); the whole grid is not O(viewport) memory.

Rows use translateY in [RowRenderer](https://github.com/revolist/revogrid/blob/52f2aab0697b70811ee704ef72046bb8aab418e8/src/components/data/row-renderer.tsx#L17); cells use translateX in [RevogrData](https://github.com/revolist/revogrid/blob/52f2aab0697b70811ee704ef72046bb8aab418e8/src/components/data/revogr-data.tsx#L288). The plain [CellRenderer](https://github.com/revolist/revogrid/blob/52f2aab0697b70811ee704ef72046bb8aab418e8/src/components/data/cell-renderer.tsx#L22) puts text directly into the cell div. Our inner span is a documented customization contract, so removing it would change behavior. RevoGrid also uses a one-item geometry buffer, while our fixed workloads retain our existing row/column overscan. Those differences prevent attributing its frame result solely to one data structure.

Our [buildRowMetrics](/home/user/git/peculiar-sheets/packages/spreadsheets/src/grid/rowMetrics.ts:119) already has arithmetic default sizes and sparse overrides. The additional layer is TanStack Virtualizer, which uses full-axis arrays even with uniform dimensions. Its installed 3.19.10 single-lane path is already optimized: Float64Array start/size pairs and lazy VirtualItem materialization, not an eager object per row.

A read-only algorithm probe of the installed runtime confirms:

| Row count | Visible items | Initial estimate calls | Estimate calls after each measure + read | Numeric geometry bytes | Key slots |
| --- | ---: | ---: | ---: | ---: | ---: |
| 10,000 | 25 | 10,000 | 10,000 each time | 160,000 | 10,000 |
| 100,000 | 25 | 100,000 | 100,000 each time | 1,600,000 | 100,000 |

The probe calls measure three times and reads virtual items after each. These are actual call counts and backing-array sizes, not UI latency measurements or a measured count of lifecycle callbacks. Key-slot and object costs are additional; byte-size guesses for them are deliberately omitted. At 100,000 rows the numeric array alone is 1.6 MB, so eliminating it alone is insufficient to explain or close the entire tall-sheet heap gap.

**First experiment:** [attachAndSnapshotVirtualizers](/home/user/git/peculiar-sheets/packages/spreadsheets/src/grid/Grid.tsx:485) unconditionally calls measure on both axes. It is used from onSettled, a repair timer and ResizeObserver. Separate observer attachment/viewport resizing from item-size invalidation; leave the lazy-loading attachment repair intact. Actual row heights and column widths already have invalidation effects. Instrument callback counts and estimate calls in real mounts, resize, lazy formula loading, and row replacement before changing behavior.

**Second experiment:** a native Solid derivation for fixed-size visible ranges, retaining the same overscan, focus, accessibility and customization behavior. Keep the existing general path for cases requiring it. This may reduce geometry memory and rebuild work; it is not yet a demonstrated horizontal-scroll frame fix, and a second virtualization path has maintenance cost. The existing sparse RowMetrics abstraction is the starting point.

## Handsontable: bounded DOM and metadata, different data ownership

[OrderView.render](https://github.com/handsontable/handsontable/blob/d6c4159ae8af1dbd3eaac30cf7b57a75a1ad1f82/handsontable/src/3rdparty/walkontable/src/utils/orderView/view.ts#L200) reuses existing element children by viewport slot. The row and cell renderers overwrite their content; dataset coordinates are not used as a cache retaining every previously visited DOM node. [CellMeta.getMeta](https://github.com/handsontable/handsontable/blob/d6c4159ae8af1dbd3eaac30cf7b57a75a1ad1f82/handsontable/src/dataMap/metaManager/metaLayers/cellMeta.ts#L173) creates metadata lazily, with [evictRow](https://github.com/handsontable/handsontable/blob/d6c4159ae8af1dbd3eaac30cf7b57a75a1ad1f82/handsontable/src/dataMap/metaManager/metaLayers/cellMeta.ts#L364) able to release render-derived metadata while preserving persisted settings. [LazyFactoryMap](https://github.com/handsontable/handsontable/blob/d6c4159ae8af1dbd3eaac30cf7b57a75a1ad1f82/handsontable/src/dataMap/metaManager/lazyFactoryMap.ts#L63) uses native Maps and buffered index shifts, rather than eagerly reindexing every stored entry for each structural operation.

Our bounded Solid row owners/Repeat columns and lazy row revision signals already follow the broad viewport-bounded pattern. That is evidence to retain them, not to replace Solid with imperative DOM pooling.

A major comparison distinction is ownership. The benchmark passes dataset.values directly to Handsontable. [DataSource.constructor](https://github.com/handsontable/handsontable/blob/d6c4159ae8af1dbd3eaac30cf7b57a75a1ad1f82/handsontable/src/dataMap/dataSource.ts#L57) retains the supplied reference, and [replaceData](https://github.com/handsontable/handsontable/blob/d6c4159ae8af1dbd3eaac30cf7b57a75a1ad1f82/handsontable/src/dataMap/replaceData.ts#L142) assigns the supplied array to its data sources. Our [createSheetStore](/home/user/git/peculiar-sheets/packages/spreadsheets/src/core/state.ts:187) copies input rows into owned state. On replacement, our adapter sends host data and our store makes owned rows; Handsontable's adapter already creates row copies before updateData. Mount and replacement therefore have different copy placement.

**Consequence:** its lower tall-sheet heap is not automatically a missing renderer optimization. A heap census should distinguish the host dataset, owned matrix, row IDs, geometry arrays, and viewport state. Sharing mutable host rows, turning off history, or using copy-on-write without validating host-mutation semantics would change our contract. I have not measured how much of the heap difference is due to each category.

## GridSheet: lazy cell objects and address-based diffs

[Sheet.initialize](https://github.com/walkframe/gridsheet/blob/b39308f5eec94b902ff572d4d6eb2e2e75184b9d/packages/engine/src/lib/sheet.ts#L992) retains deferred matrix references. [_ensureIdRow](https://github.com/walkframe/gridsheet/blob/b39308f5eec94b902ff572d4d6eb2e2e75184b9d/packages/engine/src/lib/sheet.ts#L1082) creates rows of cell IDs on demand, and [_ensureCellPopulated](https://github.com/walkframe/gridsheet/blob/b39308f5eec94b902ff572d4d6eb2e2e75184b9d/packages/engine/src/lib/sheet.ts#L1104) materializes richer cell data when accessed. [Sheet._update](https://github.com/walkframe/gridsheet/blob/b39308f5eec94b902ff572d4d6eb2e2e75184b9d/packages/engine/src/lib/sheet.ts#L2619) iterates changed addresses, collects before/after state, and [Sheet.update](https://github.com/walkframe/gridsheet/blob/b39308f5eec94b902ff572d4d6eb2e2e75184b9d/packages/engine/src/lib/sheet.ts#L2754) records one history entry for the update. That is an explicit-diff interface; our controller.setCellValues already accepts explicit mutations, whereas full controlled matrix replacement must discover them.

Its [virtualize](https://github.com/walkframe/gridsheet/blob/b39308f5eec94b902ff572d4d6eb2e2e75184b9d/packages/web/src/lib/virtualization.ts#L108) uses row boundary searches and range arrays, then [Tabular](https://github.com/walkframe/gridsheet/blob/b39308f5eec94b902ff572d4d6eb2e2e75184b9d/packages/react-core/src/components/Tabular.tsx#L521) renders keyed React rows/cells. Although [Cell](https://github.com/walkframe/gridsheet/blob/b39308f5eec94b902ff572d4d6eb2e2e75184b9d/packages/react-core/src/components/Cell.tsx#L39) is memoized, it reads the shared React Context. That is not a fine-grained subscription scheme we need to emulate; our row-scoped native Solid dependencies are already a better fit for our framework.

**Transfer:** keep rich metadata and derived cell state lazy. Do not infer that retaining its input matrix by reference is compatible with our ownership semantics. GridSheet remains optional in the suite; this review does not add unsupported interaction adapters or establish a new performance win for it.

## Univer: sparse model and incremental canvas repaint

[ObjectMatrix](https://github.com/dream-num/univer/blob/c6178bb0aae5b6d13aaadedbb87639a332d3f5e4/packages/core/src/shared/object-matrix.ts#L250) uses objects keyed by row/column, creating rows when getRowOrCreate or setValue is used. [Worksheet](https://github.com/dream-num/univer/blob/c6178bb0aae5b6d13aaadedbb87639a332d3f5e4/packages/core/src/sheets/worksheet.ts#L111) wraps the provided cell-data matrix. However, our Univer adapter creates an ICellData object for every input cell, including blanks. The model can be sparse; our benchmark conversion does not currently exploit blank omission. This distinction matters before attributing benchmark memory to an ideal sparse representation.

[Spreadsheet.renderByViewports](https://github.com/dream-num/univer/blob/c6178bb0aae5b6d13aaadedbb87639a332d3f5e4/packages/engine-render/src/components/sheets/spreadsheet.ts#L517) uses viewport cache canvases, dirty bounds and scroll deltas to choose full refresh or incremental painting. [paintNewAreaForScrolling](https://github.com/dream-num/univer/blob/c6178bb0aae5b6d13aaadedbb87639a332d3f5e4/packages/engine-render/src/components/sheets/spreadsheet.ts#L626) reuses cached pixels and paints the newly exposed regions. This is a different rendering architecture, not a DOM-cell virtualization tweak.

**Transfer:** separate data dirtiness from viewport movement and invalidate only what changed. A canvas rewrite would need a new design for our custom JSX renderers, CSS hooks, focus and accessibility; it is not the next experiment. Sparse storage might help a blank-heavy private representation, but would need to preserve the existing dense public API and does not solve dense tall-sheet memory by itself.

## Prioritized next work

1. **Count and eliminate redundant geometry invalidations.** Smallest change with direct algorithmic evidence. Preserve observer reattachment and async/lazy mount recovery. Validate viewport resizing, custom heights/widths, pinned columns and all browser contracts.
2. **Measure the ownership and geometry heap categories.** Determine which bytes are removable without changing semantics. Then evaluate fixed-size range derivation through native Solid signals/memos. Keep pure geometry helpers plain TypeScript.
3. **Reproduce the few-cell replacement result before optimizing it.** The new paired run had a higher median than 0.16.0, but an older full run of this identical current source had a much lower value. Timing variation is real. Profile the stable-cell diff, revision propagation, DOM writes, style/layout and frame alignment separately. AG Grid's unchanged-value checks suggest where to inspect; they do not prove our scan is the bottleneck.
4. **Profile actual scroll rendering after the first changes.** RevoGrid's viewport rotation and AG Grid's range checks support bounded work, but we already recycle viewport owners. Previous transform-only/CSS experiments did not improve the targeted p95; do not repeat them based solely on seeing transforms upstream. A proposed change must have a new measured mechanism.

Native Solid scheduling, row-scoped dependencies and async lifecycle ownership remain the default. Do not add a global flush, delay required work past measured frames, disable features/history, shrink overscan, change test datasets, or assume immutable input rows to get a favorable result.

## Reproduction and evidence

- Exact checkouts: [manifest](manifest.json).
- Installed-runtime probe: [geometry-probe.ts](geometry-probe.ts), [output](geometry-probe.json). Run `pnpm exec tsx .benchmark/upstream/geometry-probe.ts` from the repository root.
- Paired published-release comparison: [summary](../release-comparison/summary.json), [full bars](../release-comparison/comparison.html).
- Existing full competitor run: [snapshot](../full-checkin-current/latest.json). It is a historical, source-matched run, not a fresh run made for this review.

The proposed experiments have not been implemented or timed. Only the geometry algorithm probe was run during this review. No dependencies were installed in the cloned repositories and no upstream build scripts were executed.
