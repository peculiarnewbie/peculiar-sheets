const fs=require('fs');
const rows=[];
for(const label of ['before','after','final','aligned-before','aligned-after'])for(const lib of ['peculiar-sheets','handsontable'])for(const scenario of ['row-reorder','row-insert-delete']){
const prefix=`.benchmark/${label}-${lib}-${scenario}`;if(!fs.existsSync(prefix+'.json'))continue;const {result}=JSON.parse(fs.readFileSync(prefix+'.json'));const e=JSON.parse(fs.readFileSync(prefix+'.trace.json')).traceEvents;const mark=n=>e.find(x=>x.name===n).ts;
for(let i=0;i<result.replacement.steps.length;i++){const step=result.replacement.steps[i],idx=label.startsWith("aligned-")?3+i*3:2+i*2;const start=mark('row-frame-request-'+idx)-step.synchronousMs*1000,end=mark('row-frame-start-'+(idx+1));const cost={};for(const name of ['Layout','UpdateLayoutTree','Paint','PrePaint','Layerize']){const a=e.filter(x=>x.name===name&&x.ph==='X'&&x.ts>=start&&x.ts<end);cost[name]={calls:a.length,ms:a.reduce((s,x)=>s+(x.dur||0),0)/1000};}
rows.push({label,lib,scenario,step:step.name,synchronousMs:step.synchronousMs,firstFrameMs:(mark('row-frame-start-'+idx)-start)/1000,secondFrameMs:(end-start)/1000,cost});}}
fs.writeFileSync('.benchmark/frame-summary.json',JSON.stringify(rows,null,2));console.log(rows);


